export class Employee {
    id:number;
    firstName:string;
    lastName:string;
    dateOfBirth:Date;
    pic:File;
}
