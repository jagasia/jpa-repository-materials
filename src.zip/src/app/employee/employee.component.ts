import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employees:any;
  employeeForm:any;
  constructor(private fb:FormBuilder, private es:EmployeeService) {
    this.employeeForm=this.fb.group({
      id:[''],
      firstName:[''],
      lastName:[''],
      dateOfBirth:[''],
      pic:['']
    });
   }

  ngOnInit(): void {
    this.getEmployees();
  }

  onFileChange(event) {
    const reader = new FileReader();

    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.employeeForm.patchValue({
          tso: reader.result
        });

        // need to run CD since file load runs outside of zone
        // this.cd.markForCheck();
      };
    }
  }

  getEmployees()
  {
    this.es.getEmployees().subscribe(data=>{this.employees=data;console.log(data)});
  }

  findEmployeeById()
  {
    var id=this.employeeForm.controls.id.value;
    var employee:any;
    this.es.findEmployeeById(id).subscribe(data=>{employee=data;
      this.employeeForm.patchValue(employee);
    });    
  }
  addEmployee()
  {
    var employee=this.employeeForm.value;
    console.log(employee);
    this.es.addEmployee(employee).subscribe(data=>console.log(data));
    this.getEmployees();
  }
  updateEmployee()
  {
    var employee=this.employeeForm.value;
    this.es.updateEmployee(employee).subscribe(data=>console.log(data));
    this.getEmployees();
  }
  deleteEmployee()
  {
    var id=this.employeeForm.controls.id.value;
    this.es.deleteEmployee(id).subscribe();
    this.getEmployees();
  }
}
