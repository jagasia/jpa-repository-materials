import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  url:string='http://localhost:8080/vehicle/';
  constructor(private http:HttpClient) { }
  
  getAllVehicles()
  {
    return this.http.get(this.url);
  }
  findVehicleById(id:number)
  {
    return this.http.get(this.url+id);
  }
  addVehicle(vehicle:any)
  {
    return this.http.post(this.url,vehicle);
  }
  updateVehicle(vehicle:any)
  {
    return this.http.put(this.url,vehicle);
  }
  deleteVehicle(id:number)
  {
    return this.http.delete(this.url+id);
  }
}
