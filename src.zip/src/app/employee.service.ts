import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }

  getEmployees()
  {
    return this.http.get("http://localhost:8080/employees");
  }

  findEmployeeById(id:number)
  {
    return this.http.get("http://localhost:8080/employees/"+id);
  }

  addEmployee(employee:any)
  {
    return this.http.post("http://localhost:8080/add",employee);
  }

  updateEmployee(employee:any)
  {
    return this.http.put("http://localhost:8080/update",employee);
  }

  deleteEmployee(id:number)
  {
    return this.http.delete("http://localhost:8080/delete/"+id);
  }
}
