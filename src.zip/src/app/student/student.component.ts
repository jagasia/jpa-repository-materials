import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
students:any;
  studentForm:any;
  constructor(private ss:StudentService, private fb:FormBuilder) {
    this.studentForm=this.fb.group({
      id:[''],
      name:[''],
      dob:[''],
      gender:[''],
      departmentId:['']
    });
   }

  ngOnInit(): void {
    this.fnRead();
  }

  fnRead()
  {
    this.ss.getAllStudents().subscribe(data=>{this.students=data;console.log(data)});
  }

  fnAdd()
  {
    console.log("adding");
  //   var student= {
  //     "name": "Jag",
  //     "gender": "Male",
  //     "departmentId": 2,
  //     "dob1": "2021-12-31",
  //     "dob": "2021-12-31"
  // };
  var student=this.studentForm.value;
  this.ss.addStudent(student).subscribe(data=>{console.log(data)});
  this.fnRead();
  }

  fnEdit()
  {
    var student=this.studentForm.value;
  this.ss.editStudent(student).subscribe(data=>{console.log(data)});
  this.fnRead();
  }
}
