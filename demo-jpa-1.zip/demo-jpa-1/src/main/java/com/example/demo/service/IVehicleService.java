package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Vehicle;

public interface IVehicleService {

	void create(Vehicle vehicle);

	List<Vehicle> read();

	Vehicle read(Integer id);

	void update(Vehicle vehicle);

	void delete(Vehicle vehicle);

	List<Vehicle> findVehicleByType(String type);

}