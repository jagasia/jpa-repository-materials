package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Vehicle;
import com.example.demo.service.VehicleService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/vehicle")
public class VehicleController {

	@Autowired
	VehicleService vehicleService;
	
	@GetMapping("/")
	public List<Vehicle> getAllVehicles()
	{
		return vehicleService.read();
	}
	
	@GetMapping("/{id}")
	public Vehicle findVehicleById(@PathVariable("id") Integer id)
	{
		Vehicle vehicle=null;
		try {
		vehicle = vehicleService.read(id);
		}catch(Exception ex)
		{
			return null;
		}
		return vehicle;
	}
	
	@GetMapping("/type/{type}")
	public List<Vehicle> findVehiclesByType(@PathVariable("type") String type)
	{
		return vehicleService.findVehicleByType(type);
	}
	
	@PostMapping("/")
	public void addVehicle(@RequestBody Vehicle vehicle)
	{
		vehicleService.create(vehicle);
	}
	
	@PutMapping("/")
	public void updateVehicle(@RequestBody Vehicle vehicle)
	{
		vehicleService.update(vehicle);
	}
	
	@DeleteMapping("/{id}")
	public void deleteVehicle(@PathVariable("id") Integer id)
	{
		Vehicle vehicle=findVehicleById(id);
		vehicleService.delete(vehicle);
	}

}
